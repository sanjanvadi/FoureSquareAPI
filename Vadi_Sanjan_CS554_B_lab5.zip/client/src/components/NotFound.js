import React from "react";

const NotFound = (props)=>{
    return(
        <div>
            <p className="venueTitle">Error : 404</p>
            <p className="caption">Page Not Found</p>
        </div>
    )
}

export default NotFound;